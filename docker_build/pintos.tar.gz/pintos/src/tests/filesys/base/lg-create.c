/* Tests that create properly zeros out the contents of a fairly
   large file. */

#define TEST_SIZE 75678
#include "tests/filesys/create.inc"
